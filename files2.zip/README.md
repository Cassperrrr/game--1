# Kategoria II — Gra Zaawansowana (Architektura Średnia i Wielowątkowa)

Działająca, kompletna implementacja **Kategorii II** z raportu „Dekonstrukcja Architektury
Nowoczesnych Gier Przeglądarkowych (2026)”. To wieloosobowa arena 2D, w której każdy z
pięciu filarów architektury średniej jest zaimplementowany realnym kodem, a nie opisem.

```
Sterowanie: WSAD / strzałki.  Otwórz w 2+ kartach, by zobaczyć multiplayer.
```

---

## Pięć filarów Kategorii II → gdzie w kodzie

| # | Filar Kategorii II (z raportu) | Realizacja | Pliki |
|---|---|---|---|
| 1 | **Renderowanie WebGL 2.0 z redukcją wywołań rysowania** | Renderowanie **instancjonowane** — wszystkie byty (gracze + skrzynie + roj) w **jednym** `drawArraysInstanced`. HUD pokazuje „draw calls / klatkę = 1”. | `client/renderer-webgl2.js` |
| 2 | **Data-Oriented Design + ECS na TypedArrays (bitECS), bez GC** | Roj 1500 bytów AI w bitECS. Komponenty to płaskie `TypedArrays` (SoA), pre-alokowane (`setDefaultSize`), iterowane liniowo. Brak alokacji w pętli → brak pauz odśmiecacza. | `client/ecs/swarm.js` |
| 3 | **Wielowątkowość: Web Workers + fizyka WebAssembly** | Cała symulacja, sieć i fizyka działają w **Web Workerze**. Fizyka to **Rapier2D skompilowany z Rusta do WASM** — ten sam moduł na serwerze i u klienta. | `client/sim.worker.js`, `shared/sim.js` |
| 4 | **Autorytatywny serwer + predykcja klienta + rekoncyliacja (rollback)** | Klient przewiduje ruch lokalnie (zero input-lag), serwer jest autorytetem, klient cofa stan i **odtwarza** niepotwierdzone wejścia. Byty zdalne — interpolacja. | `client/sim.worker.js`, `server/room.js` |
| 5 | **Zoptymalizowane WebSockets + mikrousługi/orkiestracja** | Binarny protokół po WebSocket (ciasne `ArrayBuffer`, nie JSON). Serwer rozbity na **gateway + pokój (instancja)**; `docker-compose` pokazuje topologię z load balancerem. | `shared/protocol.js`, `server/`, `docker-compose.yml` |

---

## Architektura przepływu

```
   PRZEGLĄDARKA (klient)
   ┌─────────────────────────────┐         ┌──────────────────────────┐
   │  Wątek główny               │  keys   │  Web Worker              │
   │  • przechwyt wejścia ───────┼────────►│  • WebSocket (sieć)      │
   │  • WebGL2 instanced render  │◄────────┤  • predykcja (Rapier WASM)│
   │    (1 draw call)            │  frame  │  • rekoncyliacja/rollback │
   │  • recykling buforów ───────┼────────►│  • interpolacja zdalnych  │
   └─────────────────────────────┘ return  │  • ECS: roj (bitECS)     │
                                            └────────────┬─────────────┘
                                                         │ WebSocket (binarnie)
                                                         ▼
   SERWER (Node + ws)                          ┌──────────────────────────┐
   ┌──────────────────────────┐                │  gateway (index.js)      │
   │  Room: pętla 30 Hz        │◄───────────────┤  routing graczy do pokoi │
   │  • autorytatywna fizyka   │                └──────────────────────────┘
   │    Rapier WASM            │
   │  • snapshoty 20 Hz        │
   └──────────────────────────┘
```

Wątek główny robi **minimum** (rysuje gotowy bufor). Bufory pozycji są **recyklingowane**
między wątkami (`postMessage` + transferable), więc w stanie ustalonym nie ma alokacji —
to ta sama filozofia DOD co w ECS.

---

## Uruchomienie

Wymagania: Node 18+ (testowane na Node 22).

```bash
npm install

# Terminal A — autorytatywny serwer (WebSocket :8080)
npm run server

# Terminal B — klient (Vite :5173)
npm run client
```

…albo jednym poleceniem:

```bash
npm run dev      # serwer + klient równolegle
```

Otwórz `http://localhost:5173`. Dla multiplayera otwórz w kilku kartach/urządzeniach.

---

## Co zobaczysz (i jak to czytać)

- **Zielona kropka — ty.** Reaguje natychmiast (predykcja klienta), zanim serwer odpowie.
- **Pomarańczowe — inni gracze.** Płynne dzięki interpolacji (bufor 100 ms).
- **Szare kwadraty — skrzynie.** Fizyka WASM liczona autorytatywnie na serwerze; możesz w nie wpadać.
- **Niebieski roj — byty ECS.** 1500 agentów AI symulowanych w Workerze przez bitECS.
- **Panel telemetrii** — ping, tick serwera, **liczba odtworzeń rekoncyliacji**, błąd predykcji,
  liczba instancji oraz `draw calls / klatkę = 1`.

Test predykcji/rekoncyliacji: w narzędziach przeglądarki włącz throttling sieci lub po prostu
ruszaj się szybko — „błąd predykcji” chwilowo rośnie, a licznik „odtworzeń” pokazuje, ile
niepotwierdzonych wejść jest co snapshot ponownie liczonych na fizyce WASM.

---

## Granice (świadome uproszczenia względem Kategorii III)

Implementacja celowo **nie** wchodzi w Kategorię III, by pokazać dokładnie poziom średni:

- **Transport:** WebSocket (Kat. II), a nie WebTransport/QUIC (Kat. III).
- **Pamięć międzywątkowa:** `postMessage` z transferem (Kat. II), a nie `SharedArrayBuffer`
  z Cross-Origin Isolation i Zero-Copy (Kat. III).
- **Fizyka:** na CPU w WASM/Workerze (Kat. II), a nie na GPU w Compute Shaderach WebGPU (Kat. III).
- **Predykcja klienta** symuluje tylko lokalnego gracza + ściany; skrzynie i inni gracze są
  autorytatywnie serwerowe i interpolowane. To standardowy, pewny wzorzec netcode dla Kat. II.

## Uwaga o backendzie (Filar 5)

Raport wskazuje dla Kat. II backend w **Go/Java (Spring WebFlux) jako mikrousługi za load
balancerem**. Dla uruchamialności w jednym języku użyto tu **Node.js**, ale kod jest rozbity
zgodnie z tą topologią (gateway ↔ pokój). Plik `docker-compose.yml` + `infra/nginx.conf`
pokazują orkiestrację (load balancer + repliki pokoi); w produkcji usługę pokoju podmienia
się na Go/Java bez zmiany protokołu binarnego.
