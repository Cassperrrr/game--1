/**
 * Quadtree (drzewo czwórkowe) — partycjonowanie przestrzenne CPU.
 * Wersja kliencka (identyczna logika co serwerowa) używana w trybie offline.
 *
 * Kategoria I: detekcja kolizji liczona na pojedynczym wątku JS. Drzewo
 * czwórkowe zbija złożoność broadphase z O(n^2) do ~O(n log n), ale nadal
 * jest to czysty CPU — bez WebGPU Compute Shaderów (Kategoria III).
 */
export class Quadtree {
  constructor(bounds, capacity = 8, maxDepth = 6, depth = 0) {
    this.bounds = bounds;
    this.capacity = capacity;
    this.maxDepth = maxDepth;
    this.depth = depth;
    this.objects = [];
    this.divided = false;
    this.children = null;
  }

  subdivide() {
    const { x, y, w, h } = this.bounds;
    const hw = w / 2, hh = h / 2, d = this.depth + 1;
    this.children = [
      new Quadtree({ x, y, w: hw, h: hh }, this.capacity, this.maxDepth, d),
      new Quadtree({ x: x + hw, y, w: hw, h: hh }, this.capacity, this.maxDepth, d),
      new Quadtree({ x, y: y + hh, w: hw, h: hh }, this.capacity, this.maxDepth, d),
      new Quadtree({ x: x + hw, y: y + hh, w: hw, h: hh }, this.capacity, this.maxDepth, d),
    ];
    this.divided = true;
  }

  static _fits(b, it) {
    return it.x - it.r >= b.x && it.x + it.r <= b.x + b.w &&
           it.y - it.r >= b.y && it.y + it.r <= b.y + b.h;
  }

  static _intersects(b, it) {
    return !(it.x + it.r < b.x || it.x - it.r > b.x + b.w ||
             it.y + it.r < b.y || it.y - it.r > b.y + b.h);
  }

  insert(item) {
    if (!Quadtree._intersects(this.bounds, item)) return false;
    if (!this.divided) {
      if (this.objects.length < this.capacity || this.depth >= this.maxDepth) {
        this.objects.push(item);
        return true;
      }
      this.subdivide();
      const kept = [];
      for (const o of this.objects) if (!this._toChild(o)) kept.push(o);
      this.objects = kept;
    }
    if (this.divided && this._toChild(item)) return true;
    this.objects.push(item);
    return true;
  }

  _toChild(item) {
    for (const c of this.children) if (Quadtree._fits(c.bounds, item)) return c.insert(item);
    return false;
  }

  query(item, found = []) {
    if (!Quadtree._intersects(this.bounds, item)) return found;
    for (const o of this.objects) found.push(o);
    if (this.divided) for (const c of this.children) c.query(item, found);
    return found;
  }
}
