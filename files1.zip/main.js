import { Player } from './core/Player.js';
import { Bullet } from './core/Bullet.js';
import { Enemy } from './core/Enemy.js';
import { Physics } from './Physics.js';
import { Renderer } from './Renderer.js';
import { Input } from './Input.js';
import { Network } from './Network.js';

/**
 * main.js — spina wszystkie czynniki Kategorii I w jedną grę.
 *
 * PĘTLA GŁÓWNA (Game Loop) działa w JEDNYM wątku JS przez requestAnimationFrame
 * (Kategoria I): logika, fizyka i render dzielą ten sam wątek główny — to
 * opisane w raporcie krytyczne wąskie gardło architektury bazowej.
 *
 * Dwa tryby:
 *   ONLINE  — łączy się z monolitycznym serwerem (WebSocket/TCP), renderuje
 *             autorytatywne migawki z interpolacją liniową.
 *   OFFLINE — pełna symulacja lokalna (OOP + fizyka CPU + Quadtree), gdy serwer
 *             jest niedostępny (np. uruchomienie pliku index.html bez backendu).
 */

const WORLD = { w: 960, h: 600 };

const canvas = document.getElementById('game');
const renderer = new Renderer(canvas);
const input = new Input(canvas);
const net = new Network();

const ui = {
  mode: document.getElementById('mode'),
  score: document.getElementById('score'),
  fps: document.getElementById('fps'),
  ents: document.getElementById('ents'),
  banner: document.getElementById('banner'),
};

const state = {
  mode: 'offline',
  // świat offline (instancje OOP na stercie)
  player: new Player(WORLD.w / 2, WORLD.h / 2),
  bullets: [],
  enemies: [],
  physics: new Physics(WORLD),
  enemyTimer: 0,
  score: 0,
  // pomiar FPS
  frames: 0,
  fpsTimer: 0,
  fps: 0,
};

function setBanner(text, cls) {
  ui.banner.textContent = text;
  ui.banner.className = cls || '';
}

/* ---------------- TRYB OFFLINE: pełna symulacja lokalna ---------------- */

function spawnEnemyOffline() {
  const edge = Math.floor(Math.random() * 4);
  let x, y;
  if (edge === 0) { x = Math.random() * WORLD.w; y = 8; }
  else if (edge === 1) { x = WORLD.w - 8; y = Math.random() * WORLD.h; }
  else if (edge === 2) { x = Math.random() * WORLD.w; y = WORLD.h - 8; }
  else { x = 8; y = Math.random() * WORLD.h; }
  const a = Math.atan2(WORLD.h / 2 - y, WORLD.w / 2 - x) + (Math.random() - 0.5) * 0.8;
  const sp = 60 + Math.random() * 70;
  state.enemies.push(new Enemy(x, y, Math.cos(a) * sp, Math.sin(a) * sp));
}

function updateOffline(dt) {
  const p = state.player;
  const sample = input.sample(p.x, p.y);
  p.control(sample, dt);
  p.update(dt);
  state.physics.clampToWorld(p);

  if (sample.fire && p.canFire()) {
    // każdy strzał = NOWA instancja na stercie (presja na GC — patrz raport)
    state.bullets.push(new Bullet(
      p.x + Math.cos(p.angle) * (p.r + 6),
      p.y + Math.sin(p.angle) * (p.r + 6),
      p.angle, p.id
    ));
  }

  for (const b of state.bullets) b.update(dt);
  for (const e of state.enemies) e.update(dt, WORLD);

  // kolizje na CPU przez Quadtree
  const { hitBullets, hitEnemies } = state.physics.resolveBulletEnemy(state.bullets, state.enemies);
  if (hitEnemies.size) state.score += hitEnemies.size * 10;
  for (const b of state.bullets) if (hitBullets.has(b.id)) b.dead = true;
  for (const e of state.enemies) if (hitEnemies.has(e.id)) e.dead = true;

  // sprzątanie martwych bytów (dealokacja => GC w Kategorii I)
  state.bullets = state.bullets.filter((b) => !b.dead);
  state.enemies = state.enemies.filter((e) => !e.dead);

  state.enemyTimer -= dt;
  if (state.enemyTimer <= 0 && state.enemies.length < 14) {
    state.enemyTimer = 0.9;
    spawnEnemyOffline();
  }
}

function renderOffline() {
  renderer.clear();
  renderer.drawEntities(state.enemies);
  renderer.drawEntities(state.bullets);
  state.player.draw(renderer.ctx);
  ui.score.textContent = state.score;
  ui.ents.textContent = state.enemies.length + state.bullets.length + 1;
}

/* ---------------- TRYB ONLINE: autorytatywny serwer ---------------- */

function updateOnline() {
  // wysyłamy wyłącznie INPUT — serwer jest autorytatywny (klient = głuchy odbiorca)
  const self = lastSelf();
  const aimX = self ? self.x : WORLD.w / 2;
  const aimY = self ? self.y : WORLD.h / 2;
  net.sendInput(input.sample(aimX, aimY));
}

function lastSelf() {
  if (!net.curr) return null;
  return net.curr.players.find((p) => p.id === net.selfId) || null;
}

function renderOnline() {
  renderer.clear();
  const snap = net.interpolatedState();
  if (snap) {
    renderer.drawNetState(snap);
    const self = snap.players.find((p) => p.id === snap.selfId);
    ui.score.textContent = self ? self.s : 0;
    ui.ents.textContent = snap.players.length + snap.enemies.length + snap.bullets.length;
  }
}

/* ---------------- PĘTLA GŁÓWNA (jednowątkowa) ---------------- */

let last = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  if (state.mode === 'online' && net.connected) {
    updateOnline();
    renderOnline();
  } else {
    updateOffline(dt);
    renderOffline();
  }

  // licznik FPS
  state.frames++;
  state.fpsTimer += dt;
  if (state.fpsTimer >= 0.5) {
    state.fps = Math.round(state.frames / state.fpsTimer);
    ui.fps.textContent = state.fps;
    state.frames = 0;
    state.fpsTimer = 0;
  }

  requestAnimationFrame(loop);
}

/* ---------------- BOOTSTRAP: spróbuj online, w razie czego offline ---------------- */

async function boot() {
  setBanner('Łączenie z serwerem…', 'connecting');
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const url = `${proto}://${location.host}`;

  net.onWelcome = () => {
    state.mode = 'online';
    ui.mode.textContent = 'ONLINE · autorytatywny serwer (WebSocket/TCP)';
    setBanner('Połączono — symulacja po stronie serwera, interpolacja liniowa.', 'online');
    setTimeout(() => setBanner('', ''), 3500);
  };
  net.onError = () => {
    if (state.mode !== 'online') return; // już offline
    state.mode = 'offline';
    ui.mode.textContent = 'OFFLINE · lokalna symulacja CPU';
    setBanner('Utracono serwer — przełączono na tryb offline.', 'offline');
  };

  try {
    // jeśli plik otwarto bez backendu (file://), to się nie powiedzie -> offline
    await net.connect(url);
  } catch {
    state.mode = 'offline';
    ui.mode.textContent = 'OFFLINE · lokalna symulacja CPU (brak serwera)';
    setBanner('Brak serwera — gra działa lokalnie. Uruchom „npm start”, by grać w sieci.', 'offline');
    setTimeout(() => setBanner('', ''), 5000);
  }

  requestAnimationFrame(loop);
}

boot();
