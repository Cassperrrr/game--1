import { Entity } from './Entity.js';

/**
 * Bullet — pocisk.
 *
 * Raport: "ciągłe tworzenie nowych instancji pocisków podczas strzelania
 * powoduje szybkie zapełnianie pamięci". Każdy strzał = nowa instancja na
 * stercie, którą po czasie życia (ttl) usuwamy — to właśnie ten wzorzec
 * obciąża Garbage Collector w Kategorii I (brak pre-alokacji/pulowania).
 */
export class Bullet extends Entity {
  constructor(x, y, angle, owner) {
    super(x, y, 4);
    this.type = 'bullet';
    this.owner = owner;
    const speed = 460;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.ttl = 1.6;
    this.color = '#ffd23f';
  }

  update(dt) {
    super.update(dt);
    this.ttl -= dt;
    if (this.ttl <= 0) this.dead = true;
  }

  draw(ctx) {
    ctx.save();
    ctx.fillStyle = this.color;
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
