# Kategoria I — Standardowa Gra Przeglądarkowa

Kompletna, działająca realizacja **Kategorii I** z raportu *„Dekonstrukcja Architektury
Nowoczesnych Gier Przeglądarkowych (2026)”*. Projekt materializuje wszystkie pięć
„czynników pierwszych” architektury bazowej tak, jak opisuje je raport — bez technologii
z Kategorii II i III (żadnego WebGPU, WASM, ECS/TypedArrays, WebTransport ani Durable
Objects).

Gra to top-down arena: sterujesz statkiem i rozbijasz dryfujące asteroidy.

---

## Pięć czynników Kategorii I → gdzie są w kodzie

| # | Czynnik (raport) | Realizacja w kodzie |
|---|------------------|---------------------|
| 1 | **Warstwa prezentacji** — Canvas 2D API, pętla `requestAnimationFrame` w wątku głównym | `public/js/Renderer.js`, pętla w `public/js/main.js` |
| 2 | **Paradygmaty kodowe** — klasyczne OOP, instancje na stercie, presja na Garbage Collector | `public/js/core/Entity.js`, `Player.js`, `Bullet.js`, `Enemy.js` |
| 3 | **Fizyka na CPU** — sekwencyjne obliczenia, Quadtree jako partycjonowanie przestrzenne | `public/js/Physics.js`, `public/js/Quadtree.js` (oraz `server/Quadtree.js`) |
| 4 | **Transport sieciowy** — WebSockets/TCP, replikacja autorytatywna („teleportacja”) + interpolacja liniowa, brak predykcji klienta | `public/js/Network.js` ↔ `server/GameRoom.js` |
| 5 | **Infrastruktura** — monolityczny hosting (stos w stylu MERN: Node.js + Express + ws) | `server/server.js`, `package.json` |

Świadome ograniczenia (wierne raportowi): wszystko liczy jeden wątek; TCP wprowadza
ryzyko *Head-of-Line Blocking*; klient jest „głuchym odbiorcą” stanu, więc odczuwalny
jest drobny *input lag*; skalowanie wymagałoby klasycznego wynajmu maszyn i load
balancera.

---

## Uruchomienie

Wymagany Node.js 18+.

```bash
npm install
npm start
```

Następnie otwórz **http://localhost:3000**. Otwórz w kilku kartach/urządzeniach, aby
zobaczyć tryb wieloosobowy (interpolacja ruchu pozostałych graczy).

### Tryb offline (bez backendu)
Jeśli otworzysz `public/index.html` bez uruchomionego serwera, gra wykryje brak
połączenia i przejdzie w **tryb offline** — pełna symulacja lokalna (OOP + fizyka CPU +
Quadtree). To samo dzieje się, gdy serwer padnie w trakcie gry.

> Uwaga: tryb offline ładuje moduły ES (`type="module"`). Część przeglądarek blokuje
> moduły spod `file://`. Najwygodniej jest zawsze uruchomić `npm start` (Express serwuje
> pliki statyczne i WebSocket na tym samym porcie).

---

## Struktura projektu

```
kategoria-1-gra/
├── package.json            # monolityczny backend (Node + Express + ws)
├── server/
│   ├── server.js           # Express (statyki) + serwer WebSocket
│   ├── GameRoom.js         # autorytatywna symulacja świata (tick 30 Hz)
│   └── Quadtree.js         # kolizje broadphase po stronie serwera
└── public/
    ├── index.html          # powłoka gry + HUD
    ├── css/style.css       # estetyka retro-CRT
    └── js/
        ├── main.js         # pętla główna, tryby online/offline
        ├── Renderer.js     # render Canvas 2D
        ├── Physics.js      # fizyka/kolizje na CPU
        ├── Quadtree.js     # partycjonowanie przestrzenne (klient)
        ├── Network.js      # klient WebSocket + interpolacja migawek
        ├── Input.js        # klawiatura + mysz
        └── core/           # encje OOP
            ├── Entity.js
            ├── Player.js
            ├── Bullet.js
            └── Enemy.js
```

## Czego tu celowo NIE ma (granica do Kategorii II/III)
- brak WebGPU / shaderów obliczeniowych (render to czysty Canvas 2D),
- brak Data-Oriented Design / ECS / `TypedArrays` (mamy klasyczne OOP),
- brak WebAssembly i Web Workerów (cała logika w jednym wątku),
- brak WebTransport/QUIC/UDP (transport to WebSocket nad TCP),
- brak predykcji klienta i rekoncyliacji serwerowej (czysta replikacja autorytatywna),
- brak architektury brzegowej / Durable Objects (jeden monolityczny węzeł).
