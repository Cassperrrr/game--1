import { Entity } from './Entity.js';

/** Gracz — statek sterowany lokalnie (tryb offline) lub replikowany (online). */
export class Player extends Entity {
  constructor(x, y) {
    super(x, y, 16);
    this.type = 'player';
    this.speed = 220;
    this.score = 0;
    this.hp = 100;
    this.cooldown = 0;
    this.fireCooldown = 0.22;
    this.color = '#4df3ff';
  }

  control(input, dt) {
    let dx = 0, dy = 0;
    if (input.up) dy -= 1;
    if (input.down) dy += 1;
    if (input.left) dx -= 1;
    if (input.right) dx += 1;
    const len = Math.hypot(dx, dy) || 1;
    this.vx = (dx / len) * this.speed;
    this.vy = (dy / len) * this.speed;
    this.angle = input.aim ?? this.angle;
    this.cooldown -= dt;
  }

  canFire() {
    if (this.cooldown <= 0) { this.cooldown = this.fireCooldown; return true; }
    return false;
  }

  draw(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);
    // kadłub w stylu wektorowego retro
    ctx.lineWidth = 2;
    ctx.strokeStyle = this.color;
    ctx.fillStyle = 'rgba(77,243,255,0.12)';
    ctx.beginPath();
    ctx.moveTo(this.r + 6, 0);
    ctx.lineTo(-this.r, -this.r * 0.8);
    ctx.lineTo(-this.r * 0.5, 0);
    ctx.lineTo(-this.r, this.r * 0.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}
