import express from 'express';
import http from 'http';
import { WebSocketServer } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import { GameRoom } from './GameRoom.js';

/**
 * Serwer monolityczny (Kategoria I — "Infrastruktura Sieciowa i Monolityczny Hosting").
 *
 * Raport: standardowa gra opiera się na jednym, scentralizowanym węźle. Tu mamy
 * stos w stylu MERN bez bazy (Node.js + Express) z serwerem WebSocket (ws) na
 * tym samym porcie HTTP. Express serwuje statyczny frontend z /public, a ws
 * obsługuje ruch czasu rzeczywistego protokołem TCP.
 *
 * Ograniczenia wpisane w tę architekturę (zgodnie z raportem):
 *  - WebSockets => TCP => "Head-of-Line Blocking": jeden zgubiony pakiet
 *    wstrzymuje wszystkie kolejne aż do retransmisji.
 *  - Jeden proces = jeden wątek pętli zdarzeń: skalowanie wymaga klasycznego
 *    wynajmu maszyn i load balancera, a opóźnienia rosną z odległością od węzła.
 */

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const PORT = process.env.PORT || 3000;

const app = express();
app.use(express.static(PUBLIC_DIR));
app.get('/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Jeden autorytatywny pokój gry (monolit — pojedyncza instancja stanu świata).
const room = new GameRoom();

wss.on('connection', (ws) => {
  const player = room.addPlayer(ws);
  console.log(`[+] Gracz ${player.id} dołączył. Aktywnych: ${room.players.size}`);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.t === 'input') room.applyInput(ws, msg.input || {});
  });

  ws.on('close', () => {
    room.removePlayer(ws);
    console.log(`[-] Gracz ${player.id} wyszedł. Aktywnych: ${room.players.size}`);
  });

  ws.on('error', () => room.removePlayer(ws));
});

server.listen(PORT, () => {
  console.log(`\n  Kategoria I — Standardowa Gra Przeglądarkowa`);
  console.log(`  Monolityczny serwer (Express + ws) działa na:`);
  console.log(`  >  http://localhost:${PORT}\n`);
});
