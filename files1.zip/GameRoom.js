import { Quadtree } from './Quadtree.js';

/**
 * GameRoom — AUTORYTATYWNA symulacja po stronie serwera.
 *
 * Raport, Kategoria I ("Infrastruktura Sieciowa"): klient jest "głuchym
 * odbiorcą stanu z serwera centralnego". Cała logika rozgrywki (ruch, kolizje,
 * trafienia, punkty) liczona jest TUTAJ, na pojedynczym monolitycznym serwerze
 * Node.js. Klient tylko renderuje przysłane migawki (snapshots).
 *
 * Brak predykcji po stronie klienta i brak rekoncyliacji — to dopiero
 * Kategoria II. Tu mamy czystą replikację autorytatywną ("teleportacja"),
 * łagodzoną liniową interpolacją wyłącznie po stronie klienta.
 */

const WORLD = { w: 960, h: 600 };
const TICK_HZ = 30;          // częstotliwość symulacji i broadcastu (TCP/WebSocket)
const PLAYER_SPEED = 220;    // px/s
const PLAYER_RADIUS = 16;
const BULLET_SPEED = 460;
const BULLET_RADIUS = 4;
const BULLET_TTL = 1.6;      // s
const ENEMY_RADIUS = 18;
const MAX_ENEMIES = 14;
const FIRE_COOLDOWN = 0.22;  // s

let _id = 1;
const nextId = () => _id++;

export class GameRoom {
  constructor() {
    this.players = new Map();   // ws -> player state
    this.bullets = [];
    this.enemies = [];
    this.lastTick = Date.now();
    this.enemyTimer = 0;
    this.tick = this.tick.bind(this);
    this.loop = setInterval(this.tick, 1000 / TICK_HZ);
  }

  addPlayer(ws) {
    const player = {
      id: nextId(),
      type: 'player',
      x: 120 + Math.random() * (WORLD.w - 240),
      y: 120 + Math.random() * (WORLD.h - 240),
      r: PLAYER_RADIUS,
      angle: -Math.PI / 2,
      score: 0,
      hp: 100,
      input: { up: false, down: false, left: false, right: false, fire: false, aim: 0 },
      cooldown: 0,
    };
    this.players.set(ws, player);
    // odeślij klientowi jego własne id (do oznaczenia "lokalnego" gracza)
    this.send(ws, { t: 'welcome', id: player.id, world: WORLD, hz: TICK_HZ });
    return player;
  }

  removePlayer(ws) {
    this.players.delete(ws);
  }

  applyInput(ws, input) {
    const p = this.players.get(ws);
    if (!p) return;
    p.input = { ...p.input, ...input };
  }

  spawnEnemy() {
    // wjazd z losowej krawędzi w stronę środka
    const edge = Math.floor(Math.random() * 4);
    let x, y;
    if (edge === 0) { x = Math.random() * WORLD.w; y = -ENEMY_RADIUS; }
    else if (edge === 1) { x = WORLD.w + ENEMY_RADIUS; y = Math.random() * WORLD.h; }
    else if (edge === 2) { x = Math.random() * WORLD.w; y = WORLD.h + ENEMY_RADIUS; }
    else { x = -ENEMY_RADIUS; y = Math.random() * WORLD.h; }
    const cx = WORLD.w / 2, cy = WORLD.h / 2;
    const a = Math.atan2(cy - y, cx - x) + (Math.random() - 0.5) * 0.8;
    const speed = 60 + Math.random() * 70;
    this.enemies.push({
      id: nextId(), type: 'enemy', x, y, r: ENEMY_RADIUS,
      vx: Math.cos(a) * speed, vy: Math.sin(a) * speed,
      spin: (Math.random() - 0.5) * 2, angle: 0,
    });
  }

  tick() {
    const now = Date.now();
    const dt = Math.min(0.05, (now - this.lastTick) / 1000);
    this.lastTick = now;

    // --- ruch graczy (autorytatywny) ---
    for (const p of this.players.values()) {
      let dx = 0, dy = 0;
      if (p.input.up) dy -= 1;
      if (p.input.down) dy += 1;
      if (p.input.left) dx -= 1;
      if (p.input.right) dx += 1;
      const len = Math.hypot(dx, dy) || 1;
      p.x += (dx / len) * PLAYER_SPEED * dt;
      p.y += (dy / len) * PLAYER_SPEED * dt;
      p.x = Math.max(p.r, Math.min(WORLD.w - p.r, p.x));
      p.y = Math.max(p.r, Math.min(WORLD.h - p.r, p.y));
      p.angle = p.input.aim ?? p.angle;

      p.cooldown -= dt;
      if (p.input.fire && p.cooldown <= 0) {
        p.cooldown = FIRE_COOLDOWN;
        this.bullets.push({
          id: nextId(), type: 'bullet', owner: p.id,
          x: p.x + Math.cos(p.angle) * (p.r + 6),
          y: p.y + Math.sin(p.angle) * (p.r + 6),
          r: BULLET_RADIUS,
          vx: Math.cos(p.angle) * BULLET_SPEED,
          vy: Math.sin(p.angle) * BULLET_SPEED,
          ttl: BULLET_TTL,
        });
      }
    }

    // --- ruch pocisków ---
    for (const b of this.bullets) {
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.ttl -= dt;
    }
    this.bullets = this.bullets.filter(
      (b) => b.ttl > 0 && b.x > -20 && b.x < WORLD.w + 20 && b.y > -20 && b.y < WORLD.h + 20
    );

    // --- ruch wrogów ---
    for (const e of this.enemies) {
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      e.angle += e.spin * dt;
      if (e.x < e.r || e.x > WORLD.w - e.r) e.vx *= -1;
      if (e.y < e.r || e.y > WORLD.h - e.r) e.vy *= -1;
      e.x = Math.max(e.r, Math.min(WORLD.w - e.r, e.x));
      e.y = Math.max(e.r, Math.min(WORLD.h - e.r, e.y));
    }

    this.enemyTimer -= dt;
    if (this.enemyTimer <= 0 && this.enemies.length < MAX_ENEMIES) {
      this.enemyTimer = 0.9;
      this.spawnEnemy();
    }

    // --- kolizje przez Quadtree (broadphase na CPU) ---
    const qt = new Quadtree({ x: 0, y: 0, w: WORLD.w, h: WORLD.h }, 8, 6);
    for (const e of this.enemies) qt.insert(e);

    const deadBullets = new Set();
    const deadEnemies = new Set();
    for (const b of this.bullets) {
      const candidates = qt.query(b);
      for (const e of candidates) {
        if (deadEnemies.has(e.id)) continue;
        const dx = b.x - e.x, dy = b.y - e.y;
        if (dx * dx + dy * dy <= (b.r + e.r) ** 2) {
          deadBullets.add(b.id);
          deadEnemies.add(e.id);
          for (const p of this.players.values()) {
            if (p.id === b.owner) p.score += 10;
          }
          break;
        }
      }
    }
    if (deadBullets.size) this.bullets = this.bullets.filter((b) => !deadBullets.has(b.id));
    if (deadEnemies.size) this.enemies = this.enemies.filter((e) => !deadEnemies.has(e.id));

    this.broadcastSnapshot();
  }

  /** Migawka stanu wysyłana po WebSocket (TCP — uporządkowana, niezawodna). */
  broadcastSnapshot() {
    const snapshot = {
      t: 'state',
      ts: Date.now(),
      players: [...this.players.values()].map((p) => ({
        id: p.id, x: Math.round(p.x), y: Math.round(p.y),
        a: +p.angle.toFixed(2), s: p.score, hp: p.hp,
      })),
      bullets: this.bullets.map((b) => ({ id: b.id, x: Math.round(b.x), y: Math.round(b.y) })),
      enemies: this.enemies.map((e) => ({ id: e.id, x: Math.round(e.x), y: Math.round(e.y), a: +e.angle.toFixed(2) })),
    };
    const payload = JSON.stringify(snapshot);
    for (const ws of this.players.keys()) this.sendRaw(ws, payload);
  }

  send(ws, obj) { this.sendRaw(ws, JSON.stringify(obj)); }

  sendRaw(ws, payload) {
    // 1 === WebSocket.OPEN
    if (ws.readyState === 1) ws.send(payload);
  }

  dispose() { clearInterval(this.loop); }
}
