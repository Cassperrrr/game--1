/**
 * Input — przechwytywanie klawiatury i myszy w wątku głównym.
 * Sterowanie: WSAD / strzałki = ruch, mysz = celowanie, LPM / spacja = ogień.
 */
export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.state = { up: false, down: false, left: false, right: false, fire: false, aim: -Math.PI / 2 };
    this.mouse = { x: 0, y: 0 };

    window.addEventListener('keydown', (e) => this._key(e, true));
    window.addEventListener('keyup', (e) => this._key(e, false));
    canvas.addEventListener('mousemove', (e) => this._move(e));
    canvas.addEventListener('mousedown', () => (this.state.fire = true));
    window.addEventListener('mouseup', () => (this.state.fire = false));
    // spacja jako alternatywny ogień
  }

  _key(e, down) {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp': this.state.up = down; break;
      case 'KeyS': case 'ArrowDown': this.state.down = down; break;
      case 'KeyA': case 'ArrowLeft': this.state.left = down; break;
      case 'KeyD': case 'ArrowRight': this.state.right = down; break;
      case 'Space': this.state.fire = down; if (down) e.preventDefault(); break;
      default: return;
    }
  }

  _move(e) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    this.mouse.x = (e.clientX - rect.left) * scaleX;
    this.mouse.y = (e.clientY - rect.top) * scaleY;
  }

  /** Zwraca migawkę inputu, licząc kąt celowania względem pozycji gracza. */
  sample(px, py) {
    this.state.aim = Math.atan2(this.mouse.y - py, this.mouse.x - px);
    return { ...this.state };
  }
}
