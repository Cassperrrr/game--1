/**
 * Renderer — warstwa prezentacji oparta o Canvas 2D API (Kategoria I, Factor 1).
 *
 * Raport: w najprostszym paradygmacie render opiera się bezpośrednio na
 * kontekście 2D. Każda klatka to sekwencja wywołań rysowania (Draw Calls)
 * wykonywanych w wątku głównym — brak WebGPU, brak shaderów, brak GPU compute.
 */
export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.w = canvas.width;
    this.h = canvas.height;
    this._buildStars();
  }

  _buildStars() {
    this.stars = [];
    for (let i = 0; i < 90; i++) {
      this.stars.push({
        x: Math.random() * this.w,
        y: Math.random() * this.h,
        s: Math.random() * 1.6 + 0.3,
        a: Math.random() * 0.6 + 0.2,
      });
    }
  }

  clear() {
    const ctx = this.ctx;
    ctx.fillStyle = '#070912';
    ctx.fillRect(0, 0, this.w, this.h);
    // gwiazdy tła
    for (const st of this.stars) {
      ctx.globalAlpha = st.a;
      ctx.fillStyle = '#9fb3ff';
      ctx.fillRect(st.x, st.y, st.s, st.s);
    }
    ctx.globalAlpha = 1;
    // ramka areny
    ctx.strokeStyle = 'rgba(77,243,255,0.25)';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, this.w - 2, this.h - 2);
  }

  /** Render z gotowych instancji OOP (tryb offline). */
  drawEntities(entities) {
    for (const e of entities) if (!e.dead) e.draw(this.ctx);
  }

  /** Render z surowego stanu sieciowego (tryb online). */
  drawNetState(state) {
    const ctx = this.ctx;
    // wrogowie
    for (const e of state.enemies) {
      this._poly(e.x, e.y, e.a ?? 0, 18, '#ff4d6d', 'rgba(255,77,109,0.10)');
    }
    // pociski
    for (const b of state.bullets) {
      ctx.save();
      ctx.fillStyle = '#ffd23f';
      ctx.shadowColor = '#ffd23f';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    // gracze (lokalny na niebiesko, pozostali na zielono)
    for (const p of state.players) {
      const isSelf = p.id === state.selfId;
      this._ship(p.x, p.y, p.a ?? 0, isSelf ? '#4df3ff' : '#7CFF6B');
      if (isSelf) {
        ctx.save();
        ctx.fillStyle = 'rgba(77,243,255,0.5)';
        ctx.beginPath();
        ctx.arc(p.x, p.y, 24, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(77,243,255,0.35)';
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  _ship(x, y, angle, color) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.lineWidth = 2;
    ctx.strokeStyle = color;
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.beginPath();
    ctx.moveTo(22, 0);
    ctx.lineTo(-16, -13);
    ctx.lineTo(-8, 0);
    ctx.lineTo(-16, 13);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  _poly(x, y, angle, r, stroke, fill) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.lineWidth = 2;
    ctx.strokeStyle = stroke;
    ctx.fillStyle = fill;
    ctx.beginPath();
    const pts = 8;
    for (let i = 0; i < pts; i++) {
      const a = (i / pts) * Math.PI * 2;
      const rr = r * (i % 2 ? 0.82 : 1);
      const px = Math.cos(a) * rr, py = Math.sin(a) * rr;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}
