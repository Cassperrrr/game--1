/**
 * Quadtree (drzewo czwórkowe) — partycjonowanie przestrzenne CPU.
 *
 * Zgodnie z raportem (Kategoria I, "Fizyka Zależna od Procesora Centralnego"):
 * detekcja kolizji metodą "każdy z każdym" ma złożoność O(n^2). Drzewo czwórkowe
 * redukuje liczbę par do sprawdzenia, dzieląc przestrzeń rekurencyjnie na cztery
 * ćwiartki. Dzięki temu broadphase działa w praktyce ~O(n log n).
 *
 * To NADAL liczy się w całości na jednym wątku CPU (brak GPU compute shaderów,
 * które należą dopiero do Kategorii III). Powyżej kilku tysięcy ciał pojedynczy
 * wątek się "dławi" — to wbudowane ograniczenie architektury bazowej.
 */
export class Quadtree {
  /**
   * @param {{x:number,y:number,w:number,h:number}} bounds - obszar węzła
   * @param {number} capacity - ile obiektów mieści węzeł zanim się podzieli
   * @param {number} maxDepth - maksymalna głębokość rekurencji
   * @param {number} depth - bieżąca głębokość (wewnętrzne)
   */
  constructor(bounds, capacity = 8, maxDepth = 6, depth = 0) {
    this.bounds = bounds;
    this.capacity = capacity;
    this.maxDepth = maxDepth;
    this.depth = depth;
    this.objects = [];
    this.divided = false;
    this.children = null;
  }

  subdivide() {
    const { x, y, w, h } = this.bounds;
    const hw = w / 2;
    const hh = h / 2;
    const d = this.depth + 1;
    this.children = [
      new Quadtree({ x, y, w: hw, h: hh }, this.capacity, this.maxDepth, d),         // NW
      new Quadtree({ x: x + hw, y, w: hw, h: hh }, this.capacity, this.maxDepth, d),  // NE
      new Quadtree({ x, y: y + hh, w: hw, h: hh }, this.capacity, this.maxDepth, d),  // SW
      new Quadtree({ x: x + hw, y: y + hh, w: hw, h: hh }, this.capacity, this.maxDepth, d), // SE
    ];
    this.divided = true;
  }

  /** Czy AABB obiektu mieści się w danych granicach (z marginesem promienia). */
  static _fits(b, item) {
    return (
      item.x - item.r >= b.x &&
      item.x + item.r <= b.x + b.w &&
      item.y - item.r >= b.y &&
      item.y + item.r <= b.y + b.h
    );
  }

  /** Czy AABB obiektu w ogóle przecina granice węzła. */
  static _intersects(b, item) {
    return !(
      item.x + item.r < b.x ||
      item.x - item.r > b.x + b.w ||
      item.y + item.r < b.y ||
      item.y - item.r > b.y + b.h
    );
  }

  insert(item) {
    if (!Quadtree._intersects(this.bounds, item)) return false;

    if (!this.divided) {
      if (this.objects.length < this.capacity || this.depth >= this.maxDepth) {
        this.objects.push(item);
        return true;
      }
      this.subdivide();
      // przepchnij istniejące obiekty do dzieci, jeśli się w nich mieszczą
      const kept = [];
      for (const obj of this.objects) {
        if (!this._insertIntoChildren(obj)) kept.push(obj);
      }
      this.objects = kept;
    }

    if (this.divided && this._insertIntoChildren(item)) return true;
    this.objects.push(item); // obiekt na granicy ćwiartek zostaje w rodzicu
    return true;
  }

  _insertIntoChildren(item) {
    for (const child of this.children) {
      if (Quadtree._fits(child.bounds, item)) {
        return child.insert(item);
      }
    }
    return false;
  }

  /** Zwraca kandydatów potencjalnie kolidujących z danym obiektem. */
  query(item, found = []) {
    if (!Quadtree._intersects(this.bounds, item)) return found;
    for (const obj of this.objects) found.push(obj);
    if (this.divided) {
      for (const child of this.children) child.query(item, found);
    }
    return found;
  }

  clear() {
    this.objects.length = 0;
    this.divided = false;
    this.children = null;
  }
}
