/**
 * Entity — bazowa klasa OOP (Kategoria I, "Paradygmaty Kodowe").
 *
 * Raport: w architekturze bazowej każdy byt (gracz, wróg, pocisk) to OSOBNA
 * instancja klasy na stercie (heap), z własnymi metodami i właściwościami.
 * To czytelne i proste, ale generuje "Cache Misses" (obiekty rozrzucone w
 * pamięci) oraz presję na Garbage Collector przy częstej alokacji/dealokacji.
 *
 * Świadomie NIE stosujemy tu Data-Oriented Design / ECS / TypedArrays — to
 * dopiero Kategoria II. Tu pokazujemy klasyczny model obiektowy w pełnej krasie.
 */
export class Entity {
  constructor(x, y, r) {
    this.id = Entity._nextId++;
    this.x = x;
    this.y = y;
    this.r = r;          // promień kolizji (collider kołowy)
    this.vx = 0;
    this.vy = 0;
    this.angle = 0;
    this.dead = false;
    this.type = 'entity';
  }

  /** Integracja Eulera — pojedynczy wątek CPU. */
  update(dt) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;
  }

  // domyślnie pusty render; nadpisywany w podklasach
  // eslint-disable-next-line no-unused-vars
  draw(ctx) {}
}

Entity._nextId = 1;
