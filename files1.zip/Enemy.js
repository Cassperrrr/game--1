import { Entity } from './Entity.js';

/** Enemy — dryfująca asteroida/dron, odbija się od krawędzi areny. */
export class Enemy extends Entity {
  constructor(x, y, vx, vy) {
    super(x, y, 18);
    this.type = 'enemy';
    this.vx = vx;
    this.vy = vy;
    this.spin = (Math.random() - 0.5) * 2;
    this.color = '#ff4d6d';
    // statyczny, "poszarpany" kształt liczony raz (mniej alokacji w pętli)
    this.shape = [];
    const points = 8;
    for (let i = 0; i < points; i++) {
      const a = (i / points) * Math.PI * 2;
      const rr = this.r * (0.75 + Math.random() * 0.4);
      this.shape.push([Math.cos(a) * rr, Math.sin(a) * rr]);
    }
  }

  update(dt, world) {
    super.update(dt);
    this.angle += this.spin * dt;
    if (world) {
      if (this.x < this.r || this.x > world.w - this.r) this.vx *= -1;
      if (this.y < this.r || this.y > world.h - this.r) this.vy *= -1;
      this.x = Math.max(this.r, Math.min(world.w - this.r, this.x));
      this.y = Math.max(this.r, Math.min(world.h - this.r, this.y));
    }
  }

  draw(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);
    ctx.lineWidth = 2;
    ctx.strokeStyle = this.color;
    ctx.fillStyle = 'rgba(255,77,109,0.10)';
    ctx.beginPath();
    this.shape.forEach(([px, py], i) => (i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)));
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}
