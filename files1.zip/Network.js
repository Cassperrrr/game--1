/**
 * Network — klient WebSocket (Kategoria I, "Zaawansowana"... a właściwie
 * NAJPROSTSZA synchronizacja sieciowa).
 *
 * Raport ("Infrastruktura Sieciowa", "Synchronizacja stanu"):
 *  - transport: WebSockets nad TCP (niezawodny, uporządkowany => podatny na
 *    Head-of-Line Blocking, brak UDP/WebTransport z Kategorii III),
 *  - model: replikacja autorytatywna z serwera ("teleportacja") — klient jest
 *    "głuchym odbiorcą stanu",
 *  - BRAK predykcji klienta i rekoncyliacji (to Kategoria II); jedyne
 *    złagodzenie to PODSTAWOWA INTERPOLACJA LINIOWA między dwiema migawkami.
 *
 * Skutek odczuwalny przez gracza: lekkie opóźnienie reakcji na własne wejście
 * (input lag) — to celowo wierna demonstracja ograniczeń architektury bazowej.
 */
export class Network {
  constructor() {
    this.ws = null;
    this.connected = false;
    this.selfId = null;
    this.world = { w: 960, h: 600 };
    // bufor migawek do interpolacji (trzymamy 2 ostatnie)
    this.prev = null;
    this.curr = null;
    this.onWelcome = null;
    this.onError = null;
    this.renderDelay = 100; // ms — interpolujemy "w przeszłości" o ~1 tick
  }

  connect(url) {
    return new Promise((resolve, reject) => {
      let settled = false;
      try {
        this.ws = new WebSocket(url);
      } catch (err) {
        return reject(err);
      }
      const timeout = setTimeout(() => {
        if (!settled) { settled = true; reject(new Error('timeout')); this._safeClose(); }
      }, 1500);

      this.ws.onopen = () => {
        this.connected = true;
        clearTimeout(timeout);
        if (!settled) { settled = true; resolve(); }
      };
      this.ws.onerror = () => {
        clearTimeout(timeout);
        if (!settled) { settled = true; reject(new Error('ws error')); }
        if (this.onError) this.onError();
      };
      this.ws.onclose = () => {
        this.connected = false;
        if (this.onError) this.onError();
      };
      this.ws.onmessage = (ev) => this._onMessage(ev);
    });
  }

  _onMessage(ev) {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    if (msg.t === 'welcome') {
      this.selfId = msg.id;
      this.world = msg.world;
      if (this.onWelcome) this.onWelcome(msg);
    } else if (msg.t === 'state') {
      // przesuwamy okno migawek: prev <- curr <- new
      this.prev = this.curr;
      this.curr = msg;
    }
  }

  sendInput(input) {
    if (this.connected && this.ws.readyState === 1) {
      this.ws.send(JSON.stringify({ t: 'input', input }));
    }
  }

  /**
   * Zwraca interpolowany stan świata do renderu.
   * Dla zdalnych bytów liczymy pozycję liniowo między prev i curr.
   */
  interpolatedState() {
    if (!this.curr) return null;
    if (!this.prev) return this._asState(this.curr, this.curr, 0);

    const renderTime = Date.now() - this.renderDelay;
    const span = this.curr.ts - this.prev.ts || 1;
    let t = (renderTime - this.prev.ts) / span;
    t = Math.max(0, Math.min(1, t)); // clamp — bez ekstrapolacji (to byłaby predykcja)
    return this._asState(this.prev, this.curr, t);
  }

  _asState(a, b, t) {
    const lerp = (p, q) => p + (q - p) * t;
    const mapById = (arr) => {
      const m = new Map();
      for (const o of arr) m.set(o.id, o);
      return m;
    };
    const pa = mapById(a.players), ea = mapById(a.enemies), ba = mapById(a.bullets);

    const players = b.players.map((p) => {
      const old = pa.get(p.id);
      return old
        ? { ...p, x: lerp(old.x, p.x), y: lerp(old.y, p.y), a: p.a }
        : { ...p };
    });
    const enemies = b.enemies.map((e) => {
      const old = ea.get(e.id);
      return old ? { ...e, x: lerp(old.x, e.x), y: lerp(old.y, e.y), a: e.a } : { ...e };
    });
    // pociski lecą szybko i krótko żyją — interpolacja zbędna, "teleportujemy"
    const bullets = b.bullets.map((bl) => ({ ...bl }));
    return { players, enemies, bullets, selfId: this.selfId };
  }

  _safeClose() { try { this.ws && this.ws.close(); } catch { /* noop */ } }
}
