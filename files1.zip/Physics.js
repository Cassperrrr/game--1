import { Quadtree } from './Quadtree.js';

/**
 * Physics — system fizyki i kolizji liczony WYŁĄCZNIE na CPU (Kategoria I).
 *
 * Raport ("Fizyka Zależna od Procesora Centralnego"): wszystkie obliczenia
 * kinematyczne i detekcja kolizji idą sekwencyjnie przez jeden wątek JS.
 * Broadphase robimy drzewem czwórkowym, narrowphase to proste koło-koło.
 *
 * Odpowiednik biblioteki Matter.js (2D) z raportu — tu w wersji minimalnej,
 * by uczynić mechanikę Kategorii I jawną zamiast ukrytą pod frameworkiem.
 */
export class Physics {
  constructor(world) {
    this.world = world; // { w, h }
  }

  /**
   * Buduje drzewo z wrogów i sprawdza trafienia pociskami.
   * @returns {{hitBullets:Set<number>, hitEnemies:Set<number>}}
   */
  resolveBulletEnemy(bullets, enemies) {
    const qt = new Quadtree({ x: 0, y: 0, w: this.world.w, h: this.world.h }, 8, 6);
    for (const e of enemies) if (!e.dead) qt.insert(e);

    const hitBullets = new Set();
    const hitEnemies = new Set();

    for (const b of bullets) {
      if (b.dead) continue;
      const candidates = qt.query(b);          // tylko pobliscy wrogowie
      for (const e of candidates) {
        if (e.dead || hitEnemies.has(e.id)) continue;
        const dx = b.x - e.x, dy = b.y - e.y;
        const rr = b.r + e.r;
        if (dx * dx + dy * dy <= rr * rr) {      // narrowphase: koło-koło
          hitBullets.add(b.id);
          hitEnemies.add(e.id);
          break;
        }
      }
    }
    return { hitBullets, hitEnemies, treeNodes: qt };
  }

  clampToWorld(ent) {
    ent.x = Math.max(ent.r, Math.min(this.world.w - ent.r, ent.x));
    ent.y = Math.max(ent.r, Math.min(this.world.h - ent.r, ent.y));
  }
}
